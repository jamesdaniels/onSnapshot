import './firebase_list_factory.spec';
import './firebase_object_factory.spec';
import './firebase_list_observable.spec';
import './firebase_object_observable.spec';
import './query_observable.spec';
//# sourceMappingURL=index.spec.js.map