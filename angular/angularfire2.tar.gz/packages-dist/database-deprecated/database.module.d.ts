import '@firebase/database';
export declare class AngularFireDatabaseModule {
}
