import { Injectable, Inject, Optional, NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { observeOn } from 'rxjs/operator/observeOn';
import { FirebaseAppConfig, FirebaseAppName, _firebaseAppFactory, FirebaseZoneScheduler } from 'angularfire2';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/fromPromise';
export class AngularFireAuth {
    constructor(config, name, zone) {
        this.zone = zone;
        this.auth = zone.runOutsideAngular(() => {
            const app = _firebaseAppFactory(config, name);
            return app.auth();
        });
        const authState = new Observable(subscriber => {
            return zone.runOutsideAngular(() => {
                const unsubscribe = this.auth.onAuthStateChanged(subscriber);
                return { unsubscribe };
            });
        });
        this.authState = observeOn.call(authState, new FirebaseZoneScheduler(zone));
        const idToken = new Observable(subscriber => {
            return zone.runOutsideAngular(() => {
                const unsubscribe = this.auth.onIdTokenChanged(subscriber);
                return { unsubscribe };
            });
        }).switchMap((user) => {
            return user ? Observable.fromPromise(user.getIdToken()) : Observable.of(null);
        });
        this.idToken = observeOn.call(idToken, new FirebaseZoneScheduler(zone));
    }
}
AngularFireAuth.decorators = [
    { type: Injectable },
];
AngularFireAuth.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [FirebaseAppConfig,] },] },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [FirebaseAppName,] },] },
    { type: NgZone, },
];
//# sourceMappingURL=auth.js.map