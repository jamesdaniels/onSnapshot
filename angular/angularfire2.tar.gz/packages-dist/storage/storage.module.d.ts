import '@firebase/storage';
export declare class AngularFireStorageModule {
}
