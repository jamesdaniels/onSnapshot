import { ModuleWithProviders } from '@angular/core';
import '@firebase/firestore';
export declare class AngularFirestoreModule {
    static enablePersistence(): ModuleWithProviders;
}
